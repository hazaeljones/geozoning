## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=2
map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
ZK=initialZoning(qProb=c(0.45,0.85),map)
Z=ZK$resZ$zonePolygone # list of zones
lab = ZK$resZ$lab # label of zones
plotM(map = map,Z = Z,lab = lab, byLab = FALSE)
# zone 6 is a transition zone that has a common boundary with the map
numZ = 6
Estimation = Transition_Zone_Near_Boundary(map = map, Z = Z, numZ = numZ)
# compute the cost
cL = Cost_By_Laplace(map = map, Z = Z, numZ = numZ, Estimation = Estimation)
cM = Cost_By_Mean(map = map, Z = Z, numZ = numZ)
print(cL$cost_Laplace)
print(cM$cost_Mean)
# zone 6 is a zone with gradient

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=9
map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
ZK=initialZoning(qProb=c(0.65,0.8),map)
Z=ZK$resZ$zonePolygone # list of zones
lab = ZK$resZ$lab # label of zones
plotM(map = map,Z = Z,lab = lab, byLab = FALSE)
# zone 7 is a transition zone that is far from map boundary
numZ = 7
Estimation = Transition_Zone_Far_Boundary(map = map, Z = Z, numZ = numZ)
# compute the cost
cL = Cost_By_Laplace(map = map, Z = Z, numZ = numZ, Estimation = Estimation)
cM = Cost_By_Mean(map = map, Z = Z, numZ = numZ)
print(cL$cost_Laplace)
print(cM$cost_Mean)
# zone 7 is a zone with gradient

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=6
map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
ZK=initialZoning(qProb=c(0.8),map)
Z=ZK$resZ$zonePolygone # list of zones
lab = ZK$resZ$lab # label of zones
plotM(map = map,Z = Z,lab = lab, byLab = FALSE)
# zone 2 is a zone with maximum label
numZ = 2
Estimation = Extreme_Zone(map = map, Z = Z, numZ = numZ, label.is.min = FALSE)
# compute the cost
cL = Cost_By_Laplace(map = map, Z = Z, numZ = numZ, Estimation = Estimation)
cM = Cost_By_Mean(map = map, Z = Z, numZ = numZ)
print(cL$cost_Laplace)
print(cM$cost_Mean)
# zone 2 is homogeneous

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=6
map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
ZK=initialZoning(qProb=c(0.67,0.8),map)
Z=ZK$resZ$zonePolygone # list of zones
lab = ZK$resZ$lab # label of zones
plotM(map = map,Z = Z,lab = lab, byLab = FALSE)
# zone 4 and 6 are transition zones and have exactly 2 neighbours with different labels.
list_Zone_2_Neighbours(Z = Z, lab = lab)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=2
map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
ZK=initialZoning(qProb=c(0.55,0.85),map)
Z=ZK$resZ$zonePolygone # list of zones
lab = ZK$resZ$lab # label of zones
plotM(map = map,Z = Z,lab = lab, byLab = FALSE)
# zone 6 is a transition zone that has commun boundary with the map
numZ = 6
Estimation = Transition_Zone_Near_Boundary(map = map, Z = Z, numZ = numZ)

result = new_krigGrid_for_visualisation(map = map, Z = Z, numZ = numZ, solution = Estimation)
new_krigGrid = result$new_krigGrid
new_data = result$new_data
quant1 = quantile(map$krigData@data$var1.pred,probs = 0.55)
quant2 = quantile(map$krigData@data$var1.pred,probs = 0.85)

# plot initial isocontours
plotM(map = map,Z = Z,lab = lab, byLab = TRUE)
listContours = contourBetween(map = map, krigGrid = map$krigGrid, q1 = quant1, q2 = quant2)
for (i in 1:length(listContours)){
  plot(listContours[[i]]$contour,add=TRUE,col = "red")
}
# plot modified isocontours
plotM(map = map,Z = Z,lab = lab, byLab = TRUE)
listContours = contourBetween(map = map, krigGrid = new_krigGrid, q1 = quant1, q2 = quant2)
for (i in 1:length(listContours)){
  plot(listContours[[i]]$contour,add=TRUE,col = "red")
}


## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

