## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
 
  seed=80
  map=genMap(DataObj=NULL,seed=seed,disp=0,krig=2)

  # display 2D map
  plotMap(map)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   ZK=initialZoning(qProb=c(0.4,0.7),map,pErr=0.9,simplitol=1e-3,optiCrit=2,disp=0) # names(Z)  "resCrit"  "resDist" "resZ"
   # initialZoning calls zoneGeneration, calNei, calDistance, calCrit
   # zoneGeneration calls contourAuto
   # contourAuto calls contourLines and extensionLine
   Z=ZK$resZ$zonePolygone
   K=ZK$resZ

   plotZ(Z) #only zones
   # obtain normalized corrected distance matrix
   DC0=ZK$resD$matDistanceCorr
   DC0N=normDistMat(DC0,2)
 

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  # more detailed plot
  valRef=quantile(map$krigGrid,na.rm=TRUE,prob=c(0.4,0.7))
  dispZ(map$step,map$krigGrid,zonePolygone=Z,K=K,boundary=map$boundary,nbLvl=0,id=FALSE,mu=2)
  title(paste(" q=[",toString(round(valRef,2)),"]   crit=",round(ZK$resCrit,2),sep=""))
  
  # print zoning labels
  printLabZ(list(ZK$resZ))
  # print zoning surfaces
  printZsurf(ZK$resZ$zonePolygone)
  # print zoning ids
  printZid(ZK$resZ$zonePolygone)
  

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

