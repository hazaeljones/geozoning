## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(ggplot2)
  library(sp)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  data(yield)
  plot(x=yield$x, y=yield$y)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  boundary0=list()
  boundary0$x=c(7723128,7723223,7723283,7723376,7723430,7723453,7723605,7723713,7723699,7723638,7723696,7723707,
                7723562,7723531,7723494,7723459,7723344,7723356,7723221,7723158,7723129)

  boundary0$y=c(3576538,3576438,3576432,3576396,3576386,3576388,3576776,3577000,3577054,3577104,3577175,3577202,
                3577389,3577388,3577455,3577445,3577211,3577151,3576860,3576697,3576547)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  boundary0$x[length(boundary0$x)]=boundary0$x[1]
  boundary0$y[length(boundary0$y)]=boundary0$y[1]
  
  boundary1<-cbind.data.frame(boundary0$x,boundary0$y)
  colnames(boundary1)<-c("x","y")

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  ggplot(data=yield,aes(x=x,y=y,colour=Yield)) + geom_point() #+
    geom_line(data=boundary1, aes(x=x,y=y),col="red")

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
plot(x=yield$x, y=yield$y)
lines(boundary0$x,boundary0$y,col="red")

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
resNorm = datanormX(yield, boundary0)
  if (is.null(resNorm)) print("error in coordinates")
  yieldN = resNorm$dataN 
  boundaryN = resNorm$boundaryN
  xmin=resNorm$xmin
  xmax=resNorm$xmax
  ymin=resNorm$ymin
  ymax=resNorm$ymax
  ratio=resNorm$ratio

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  plot(x=yieldN$x, y=yieldN$y)
  lines(boundaryN$x,boundaryN$y,col="red")

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  map=genMap(yieldN,seed=0,boundary=boundaryN,disp=0,nPointsK=7000)
  boundary=map$boundary

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
 minSize = 0.012 # default zone surface threshold 
 minSizeNG= 1e-3 # default threshold for both no grow and zone grow
 
 resT=normSize(boundaryN,minSize,minSizeNG)
 minSize=resT$minSize
 minSizeNG=resT$minSizeNG

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  shape1<-geozoning::shape1
  #obtention of coords
  p = shape1@polygons
  sp=list()
  for (k in 1:length(p))
  {
  	sp[[k]] = (p[[k]]@Polygons)[[1]]
  	co=coordinates(sp[[k]])
	  co[,1]=(co[,1]-xmin)/(xmax-xmin)
	  co[,2]=(co[,2]-ymin)/(xmax-xmin)
	  sp[[k]]@coords=co
	  sp[[k]] = polyToSp2(sp[[k]])
	}
  
  NZ=length(sp)
  for (iZ in 1:NZ)
  {
	  sp=setId(sp,iZ,iZ)
  }

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  K =calNei(sp,map$krigData,map$krigSurfVoronoi,map$krigN,simplitol=simplitol)
  # zoning Z is obtained as follows
  Z =K$zonePolygone
  nZ=length(Z)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  dispZ(map$step,map$krigGrid,zonePolygone=Z,K=K,boundary=map$boundary,nbLvl=0)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  resD = calDistance(typedist=1,map$krigData,K$listZonePoint,K$zoneN,map$krigSurfVoronoi,K$meanZone,pErr=0.9)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  print(normDistMat(resD$matDistanceCorr,2)) # zone pairs (6,7) and (4,8) have low distance values

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  crit = calCrit(resD$matDistanceCorr,K$zoneNModif,2) # crit is the mimimum distance value (between zones 6 and 7)
  print(crit)

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

