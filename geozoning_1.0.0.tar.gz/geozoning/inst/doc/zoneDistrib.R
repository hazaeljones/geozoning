## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(sp)
  library(fields)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  seed=40
  map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=1,Vnugget=1.2)
# Check the mean and standard deviation of generated data.
  meanvarSimu(map)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   
   ################################################################
   qProb=c(0.275,0.8)
   criti=correctionTree(qProb,map,LASTPASS=FALSE)
   # find best corrected zoning among last level zonings (7 zones in this case)
   res=searchNODcrit1(qProb,criti)
   b=res$ind[[1]][1]
   K=criti$zk[[2]][[b]]
   Z=K$zonePolygone
   plotZ(Z,id=TRUE)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   val=valZ(map,K)$val
   ord=valZ(map,K)$ord
   Z=orderZ(Z,ord)
   plotZ(Z,id=TRUE)
   #plot zoning together with zone distribution of values
   palCol=colorRampPalette(c("brown","yellow"))
   dispZ(map$step,map$krigGrid,zonePolygone=Z,id=TRUE,palCol=palCol(length(val)))
   boxplot(val,col=palCol(length(val)))
   # another color palette
    dispZ(map$step,map$krigGrid,zonePolygone=Z,id=TRUE,palCol=topo.colors)
   boxplot(val,col=topo.colors(length(val)))


# Session informations

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

