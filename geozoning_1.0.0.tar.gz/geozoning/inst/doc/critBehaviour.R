## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  seed=10
  map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=1)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  ro=loopQ3(map,step=0.1,disp=0,QUIET=T)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  bqProb=ro[1,5:7]
  criti=correctionTree(bqProb,map,SAVE=TRUE)
  res=searchNODcrit1(bqProb,criti)
  b=res$ind[[1]][1]
  K=criti$zk[[2]][[b]]
  bZ=K$zonePolygone
  dispZ(map$step,map$krigGrid,zonePolygone=bZ)
  # distance matrix has high values, criterion is the smallest one (6.417), distance between zones 5 and 7
  bmd=criti$mdist[[2]][[b]]
  bcrit=criti$criterion[[2]][[b]]
  bcrit
  bmd

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  wqProb=ro[56,5:7]
  criti=correctionTree(wqProb,map,SAVE=TRUE)
  res=searchNODcrit1(wqProb,criti)
  w=res$ind[[1]][1]
  K=criti$zk[[2]][[w]]
  wZ=K$zonePolygone
  dispZ(map$step,map$krigGrid,zonePolygone=wZ)
  # distance matrix has some low values, criterion is the smallest one (3.747), distance between zones 4 and 8
  wmd=criti$mdist[[2]][[w]]
  wcrit=criti$criterion[[2]][[w]]
  wcrit
  wmd

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

