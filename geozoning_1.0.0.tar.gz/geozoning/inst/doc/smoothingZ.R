## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(rgeos)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=1
map=genMap(DataObj=NULL,seed=seed,disp=0,krig=2)
criti = correctionTree(qProb = c(0.5), map = map)
Z = criti$zk[[1]][[1]]$zonePolygone
lab = criti$zk[[1]][[1]]$lab
plotM(map = map, Z = Z, lab = lab, byLab = FALSE)
class(gIntersection(Z[[1]],Z[[2]])) [1]
class(gIntersection(Z[[1]],Z[[5]])) [1]
class(gIntersection(Z[[2]],Z[[3]])) [1]
class(gIntersection(Z[[2]],Z[[4]])) [1]
res = correctBoundaryMap(Zi = Z, map = map)
Z = res$Z
class(gIntersection(Z[[1]],Z[[2]])) [1]
class(gIntersection(Z[[1]],Z[[5]])) [1]
class(gIntersection(Z[[2]],Z[[3]])) [1]
class(gIntersection(Z[[2]],Z[[4]])) [1]

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------

seed=1

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
map=genMap(DataObj=NULL,seed=seed,disp=0,krig=2)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
criti = correctionTree(qProb = c(0.5), map = map)
Z = criti$zk[[1]][[1]]$zonePolygone
lab = criti$zk[[1]][[1]]$lab

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
res = correctBoundaryMap(Zi = Z, map = map)
Z = res$Z
# map boundary after correction
boundary = Z[[1]]
for(i in 2:length(Z)){
  boundary = gUnion(boundary, Z[[i]])
}
#plot map
plotM(map = map, Z = Z, lab = lab, byLab = FALSE)
# smoothing
zone = Z[[2]]
plot(zone)
newZone = smoothingZone(z = zone, width = 0.05, boundary = boundary)
plot(newZone)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
widthMax = cal.max.width.Zone(z = Z[[3]], step = 0.001, widthMax = 0.05, boundary = boundary, erosion = TRUE)
zone = zone.extended(z = Z[[3]], boundary = boundary)
erosion1 = gBuffer(zone ,width = - (widthMax + 0.002) ,joinStyle="ROUND",capStyle = "ROUND")
erosion2 = gBuffer(zone ,width = - (widthMax - 0.002) ,joinStyle="ROUND",capStyle = "ROUND")
plot(erosion1)

plot(erosion2)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
seed=1
map=genMap(DataObj=NULL,seed=seed,disp=0,krig=2)
criti = correctionTree(qProb = c(0.4,0.6), map = map)
Z = criti$zk[[2]][[1]]$zonePolygone
newZ = smoothingMap(Z = Z, width = 0.05, map = map, disp = TRUE)
plotM(map = map, Z = Z, lab = 1:length(Z))
plotM(map = map, Z = newZ, lab = 1:length(newZ))

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
#data(yieldMapZ)
#plotM(map = map, Z = Z3, lab = 1:length(Z3))

#res = correctBoundaryMap(Zi = Z3, map = map)
#Z = res$Z
#newZ = smoothingMap(Z = Z, width = 0.05, map = map, disp = TRUE)
#plotM(map = map, Z = newZ, lab = 1:length(newZ))
   

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

