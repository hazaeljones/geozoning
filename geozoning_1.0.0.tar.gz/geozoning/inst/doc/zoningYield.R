## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(ggplot2)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
# Import yield data
  data(yield)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  # draw manual boundary
  boundary0=list()
  boundary0$x=c(7723128,7723223,7723283,7723376,7723430,7723453,7723605,7723713,7723699,7723638,7723696,7723707,
                7723562,7723531,7723494,7723459,7723344,7723356,7723221,7723158,7723129)

  boundary0$y=c(3576538,3576438,3576432,3576396,3576386,3576388,3576776,3577000,3577054,3577104,3577175,3577202,
                3577389,3577388,3577455,3577445,3577211,3577151,3576860,3576697,3576547)

  boundary0$x[length(boundary0$x)]=boundary0$x[1]
  boundary0$y[length(boundary0$y)]=boundary0$y[1]
  
  boundary1<-cbind.data.frame(boundary0$x,boundary0$y)
  colnames(boundary1)<-c("x","y")
  
  # plot data
  ggplot(data=yield,aes(x=x,y=y,colour=Yield)) + geom_point() #+
    geom_line(data=boundary1, aes(x=x,y=y),col="red")
 

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  #  x and y coordinates are normalized in genMap with (xmax-xmin) ratio

  # build map data based on yield data
  map=genMap(yield,seed=0,boundary=boundary0,disp=0,nPointsK=3000,krig=1)
  boundaryN=map$boundary
  dispZ(map$step,matVal=map$krigGrid,zonePolygone=NULL,boundary=map$boundary)
  


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
# test zoning with one quantile (median value)
qProb=0.5
ZK = initialZoning(qProb,map)
K=ZK$resZ
Z=K$zonePolygone
dispZ(map$step,map$krigGrid,zonePolygone=Z,K=K,boundary=map$boundary,nbLvl=0,id=FALSE)

#apply corrections and display detailed information at each step
criti= correctionTree(qProb=c(0.5),map,minSize=minSize,minSizeNG=minSizeNG,disp=1)
# search for best criterion at last level (once all corrections have been applied)
res=searchNODcrit1(qProb,criti)
b=res$ind[[1]][1]
K=criti$zk[[2]][[b]]
Z=K$zonePolygone
dispZ(map$step,map$krigGrid,zonePolygone=Z,K=K,boundary=map$boundary,nbLvl=0,id=FALSE)
#
#Run exploratory loops to find the best zonings for nL=2 to 5
#Set reasonable values for minimum size of zones and size threshold for not trying to grow zones (just remove them)
minSizeNG=1e-2
minSize=2e-2
#
ro1=loopQ1(map,disp=0,step=0.15,minSize=minSize,minSizeNG=minSizeNG)
ro2=loopQ2(map,disp=0,step=0.15,minSize=minSize,minSizeNG=minSizeNG)
ro3=loopQ3(map,disp=0,step=0.15,minSize=minSize,minSizeNG=minSizeNG)
ro4=loopQ4(map,disp=0,step=0.15,minSize=minSize,minSizeNG=minSizeNG)
# study results, first plot criteria
best=figCritN(m1=ro1,m2=ro2,m3=ro3,m4=ro4,NEW=TRUE,ONE=TRUE,title="Yield data",pdf=NULL)
# best probability vectors for a number of labels between 2 and 5
m1=best[1]
m2=best[2:3]
m3=best[4:6]
m4=best[7:10]
# build best zonings for a given number of labels (between 2 and 5), that implies calculating corrections for the best zonings determined in the exploration loop
# assign corresponding objects Z1, Z2, Z3, Z4 and values val1, val2, val3, val4
for (k in 1:4)
    {
	mk=get(paste("m",k,sep=""))
	critk=correctionTree(mk,map,disp=0,SAVE=T)
	res=searchNODcrit1(mk,critk)
	jj=res$ind[[1]][1]
	zk=critk$zk
	K=zk[[length(zk)]][[jj]]
	# order zones by increasing average zone value
	valk=valZ(map,K)$val
	ordk=valZ(map,K)$ord
	Zk=K$zonePolygone
	ii=0
	for (iZ in ordk)
    	    {
		ii=ii+1
    		Zk=setId(Zk,iZ,ii)
    	     }
	Zkname=paste("Z",k,sep="")
	assign(Zkname,Zk)
	valkname=paste("val",k,sep="")
	assign(valkname,valk)
    }

# for 4 labels, display data, best zonings and distribution of values within zones (boxplot)
   palCol=colorRampPalette(c("brown","yellow"))
   dispZ(map$step,map$krigGrid,zonePolygone=Z3,id=TRUE,palCol=palCol(length(Z3)))
   title("Best Zoning for nL=4")
   boxplot(val3,col=palCol(length(val3)))
    title("Distribution of values within zones")

# Session informations

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

