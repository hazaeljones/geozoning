## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(sp)
  library(fields)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  seed=80
  map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2,Vmean=15)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
plotMap(map)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  meanvarSimu(map)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
qq=quantile(map$krigGrid,na.rm=TRUE,prob=c(0.5,0.7))
dispZ(map$step,map$krigGrid,valQ=qq)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   ZK=initialZoning(c(0.5,0.7),map) # names(ZK)  "resCrit"  "resDist" "resZ" "cL" "qProb"

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   K=ZK$resZ
   Z=K$zonePolygone
   plotZ(Z)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
    dispZ(map$step,map$krigGrid,zonePolygone=Z)
   # Outline boundaries of zone 3
   dispZ(map$step,map$krigGrid,zonePolygone=Z,iZ=3)
   # Outline all polygons of zone 3- It contains 4 polygons
   linesSp(Z[[3]],col="blue") # first one in blue
   linesSp(Z[[3]],k=2,col="red") # second one in red, and so on
   # A zone can have one or several holes, and each hole is an independent zone.zone 3 has 3 holes (zones 9, 10, 11). Due to its shape and to the common borders with the map boundary, zone 12 is not a hole in zone 3.
   holeSp(Z[[3]])

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
dispZ(map$step,map$krigGrid,zonePolygone=Z,K=K,boundary=map$boundary,nbLvl=0,id=FALSE,mu=2) 
  title(paste(" q=[",toString(round(qq,2)),"]   crit=",round(ZK$resCrit,2),sep="")) # add quantile values and criterion value for Z.
  # print zone labels
  printLabZ(list(K))
  # print zone areas
  printZsurf(K$zonePolygone)
  # print zone ids
  printZid(Z)
  # remove zones with less than 5 data points
  K=calNei(Z,map$krigData,map$krigSurfVoronoi,map$krigN,nmin=10)
  plotZ(K$zonePolygone)


## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
criti<-correctionTree(c(0.4,0.7),map,SAVE=TRUE,ALL=TRUE,LASTPASS=FALSE,distIsoZ=0.001)#save all branches resulting from correction steps
zk=criti$zk

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   Z21=zk[[2]][[1]]$zonePolygone
   Z22=zk[[2]][[2]]$zonePolygone
   plotZ(Z21,id=TRUE) # result of removal of zone #7
   plotZ(Z22,id=TRUE) # result of growing of zone #7
   # then the correction procedure is done for zone #8 in these two zonings
   for (ii in 1:length(zk[[3]]))
   {
   plotZ(zk[[3]][[ii]]$zonePolygone) # result of removal of zone #8 in Z21
   }
   #successively:  removal of zone#8  in Z21, growing of zone#8  in Z21
   # removal of zone#8  in Z22, growing of zone#8  in Z22
   criti<-correctionTree(c(0.4,0.7),map,SAVE=TRUE,ALL=TRUE,LASTPASS=TRUE,distIsoZ=0.001)#other try with LASTPASS=TRUE removes at last step the zones that are still too small after all successive corrections
   # other run with ALL=FALSE saves memory by keeping only the first and the last levels
   criti<-correctionTree(c(0.4,0.7),map,SAVE=TRUE,ALL=FALSE,LASTPASS=FALSE,distIsoZ=0.001)

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

