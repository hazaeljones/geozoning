## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
  library(geozoning)
  library(sp)
  library(fields)

## ----echo=TRUE,message=FALSE, warning=FALSE,fig.height=10----------------
  seed=80
  map=genMap(DataObj=NULL,seed=seed,disp=FALSE,krig=2)
# Check the mean and standard deviation of generated data.
  meanvarSimu(map)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   qProb=c(0.5,0.7)
   qq=quantile(map$krigGrid,na.rm=TRUE,prob=qProb)
   ZK=initialZoning(qProb,map) # names(ZK)  "resCrit"  "resDist" "resZ" "cL" "qProb"
   # plot zoning (11 zones in this case)
   K=ZK$resZ
   Z=K$zonePolygone
   plotZ(Z)
   printLabZ(list(K)) # zones 9 to 11 have the same label(1)

## ----echo=TRUE,message=FALSE, warning=FALSE------------------------------
   kmi=optiRG(K,map,9,10,disp=1)
   plotZ(kmi$zonePolygone)
  
   

## ----session,echo=FALSE,message=FALSE, warning=FALSE---------------------
  sessionInfo()

