#rm(list=ls())
library(geozoning)
#source("srcZ.R")
#library(caTools)
#library(png)
#
#save(map,resNorm,boundaryN,boundary,minSize,minSizeNG,best,crit1,m1,Z1,val1,crit2,m2,Z2,val2,crit3,m3,Z3,val3,crit4,m4,Z4,val4,crit5,m5,Z5,val5, file="yieldMap+Z.Rdata")
#load("yieldMap+Z.Rdata")

source("prep_real_data-yield.R") # assigns map and other parameters
ratio=max(DataCsv$x)-min(DataCsv$x)
pErr=0.9
#
# read exploration loop results
f1=read.table(paste("res-yield-1q-pE",pErr,".csv",sep=""))
f2=read.table(paste("res-yield-2q-pE",pErr,".csv",sep=""))
f3=read.table(paste("res-yield-3q-pE",pErr,".csv",sep=""))
f4=read.table(paste("res-yield-4q-pE",pErr,".csv",sep=""))
f5=read.table(paste("res-yield-5q-pE",pErr,".csv",sep=""))

best=unlist(c(f1[1,5],f2[1,5:6],f3[1,5:7],f4[1,5:8],f5[1,5:9]))
names(best)=NULL

# 1q
m1=best[1]
crit1=correctionTree(m1,map,disp=0,SAVE=T)
res=searchNODcrit1(m1,crit1)
jj=res$ind[[1]][1]
zk=crit1$zk
K1=zk[[length(zk)]][[jj]]
val1=valZ(map,K1)$val
ord1=valZ(map,K1)$ord
Z1=K1$zonePolygone
k=0
for (iZ in ord1)
{
k=k+1
Z1=setId(Z1,iZ,k)
}
#

#2q
m2=best[2:3]
#m2=c(0.125,0.575) #variante du meilleur zonage avec krigeage interp. inverse
crit2=correctionTree(m2,map,disp=0,SAVE=T)
res=searchNODcrit1(m2,crit2)
jj=res$ind[[1]][1]
zk=crit2$zk
K2=zk[[length(zk)]][[jj]]
val2=valZ(map,K2)$val
ord2=valZ(map,K2)$ord
Z2=K2$zonePolygone
k=0
for (iZ in ord2)
{
k=k+1
Z2=setId(Z2,iZ,k)
}

#3q
m3=best[4:6]
crit3=correctionTree(m3,map,disp=0,SAVE=T)
zk=crit3$zk
res=searchNODcrit1(m3,crit3)
jj=res$ind[[1]][1]
K3=zk[[length(zk)]][[jj]]
val3=valZ(map,K3)$val
ord3=valZ(map,K3)$ord
Z3=K3$zonePolygone
k=0
for (iZ in ord3)
{
k=k+1
Z3=setId(Z3,iZ,k)
}

#4q
m4=best[7:10]
crit4=correctionTree(m4,map,disp=0,SAVE=T)
zk=crit4$zk
res=searchNODcrit1(m4,crit4)
jj=res$ind[[1]][1]
K4=zk[[length(zk)]][[jj]]
val4=valZ(map,K4)$val
ord4=valZ(map,K4)$ord
Z4=K4$zonePolygone
k=0
for (iZ in ord4)
{
k=k+1
Z4=setId(Z4,iZ,k)
}

#5q
m5=best[11:15]

crit5=correctionTree(m5,map,disp=0,SAVE=T)
zk=crit5$zk
res=searchNODcrit1(m5,crit5)
jj=res$ind[[1]][1]
K5=zk[[length(zk)]][[jj]]
val5=valZ(map,K5)$val
ord5=valZ(map,K5)$ord
Z5=K5$zonePolygone
k=0
for (iZ in ord5)
{
k=k+1
Z5=setId(Z5,iZ,k)
}

# non normalized yield data
xr=range(DataCsv$x)
yr=range(DataCsv$y)
mx=xr[2]-xr[1]
my=yr[2]-yr[1]
st=0.012 # normalized grid
stx=st*mx
sty=st*my
di=sqrt(mx^2+my^2)


#variogram
data=map$rawData #raw data
empvario=RFempiricalvariogram(data=data)
png("empvario.png")
plot(empvario)
dev.off()

#criteria
cri=c()
for (n in 1:5)
{
Zname=paste("Z",n,sep="")
Z=get(Zname)
cri=c(cri,calcDCrit(Z,map,optiCrit=optiCrit,simplitol=silplitol)$resCrit)
}
cri

x11(width=6,height=10)
dispZmap(map,Z1,best[1],val1,scale=ratio)
x11(width=6,height=10)
dispZmap(map,Z2,best[2:3],val2,scale=ratio)
x11(width=6,height=10)
dispZmap(map,Z3,best[4:6],val3,scale=ratio)
x11(width=6,height=10)
dispZmap(map,Z4,best[7:10],val4,scale=ratio)
x11(width=6,height=10)
dispZmap(map,Z5,best[11:15],val5,scale=ratio)


png("yieldZD1.png",width=600,height=1000)
dispZmap(map,Z1,best[1],val1,scale=ratio)
dev.off()
png("yieldZD2.png",width=600,height=1000)
dispZmap(map,Z2,best[2:3],val2,scale=ratio)
dev.off()
png("yieldZD3.png",width=600,height=1000)
dispZmap(map,Z3,best[4:6],val3,scale=ratio)
dev.off()
png("yieldZD4.png",width=600,height=1000)
dispZmap(map,Z4,best[7:10],val4,scale=ratio)
dev.off()
png("yieldZD5.png",width=600,height=1000)
dispZmap(map,Z5,best[11:15],val5,scale=ratio)
dev.off()
