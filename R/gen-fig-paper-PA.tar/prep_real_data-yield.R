# read real data (csv in R)
# Corentin yield data


options(warning=0)

#read csv with data
file="CASESTUDYFUNCTIONS/yield.csv"
DataCsv = read.table(file,sep=",",header = TRUE)
colnames(DataCsv)=c("x","y","Yield")
#read border
plot(x=DataCsv$x, y=DataCsv$y)
#boundary0=locator(500,type="l")
# draw manual boundary
boundary0=list()
boundary0$x=c(7723128,7723223,7723283,7723376,7723430,7723453,7723605,7723713,7723699,7723638,7723696,7723707,7723562,7723531,7723494,7723459,7723344,7723356,7723221,7723158,7723129)

boundary0$y=c(3576538,3576438,3576432,3576396,3576386,3576388,3576776,3577000,3577054,3577104,3577175,3577202,3577389,3577388,3577455,3577445,3577211,3577151,3576860,3576697,3576547)

boundary0$x[length(boundary0$x)]=boundary0$x[1]
boundary0$y[length(boundary0$y)]=boundary0$y[1]
# plot data
qplot(x=DataCsv$x, y=DataCsv$y, data=DataCsv, colour=DataCsv[,3])
plot(x=DataCsv$x, y=DataCsv$y)
lines(boundary0$x,boundary0$y,col="red")

# normalize x and y coordinate with (xmax-xmin) ratio
# done in genMap

#compute zoning on normalized data
# build  kriging data based on real data DataCsvN
#krig=2 #inverse distance interpolation
krig=1#model-based interpolation for PA paper
nptsK=2000
#nptsK=6000 #for PA paper
map=genMap(DataObj=DataCsv,seed=0,boundary=boundary0,nPointsK=nptsK,krig=krig,disp=0)

# transform minSize as a percentage of frame
# compute frame area
resT=normSize(map$boundary,minSize,minSizeNG)
minSize=resT$minSize
minSizeNG=resT$minSizeNG
xmin=min(boundary0$x)
xmax=max(boundary0$x)
ymin=min(boundary0$y)
