#source("srcZ.R")
library(geozoning)
#setwd("RES-50SIMUS-krig1-Vpsill5-Vrange0.2-Vmean8-Vnugget1.2/")

## 50 simus
vseed=listSeeds()
## for each simu, get criterion values
#mc=NULL
#for (k in 1:length(vseed))
#{
## remove degenerate quantiles-keep best crit for each number of labels and each simu
#res=selMaps(seed=vseed[k],thr=thr,med=NULL,medC=NULL,m1=NULL,m2=NULL,m3=NULL,m4=NULL,pErr=0.9)
#mc=rbind(mc,res$crit)
#}

#png("boxplot-nugget1.2.png")
#boxplot(mc,names=paste("nL=",2:6,sep=""))
#dev.off()


# study results for 1 simu
#
vseed1=40
for (seed in vseed1)
{
krig=1 #Gaussian model for kriging
Vpsill=5
Vrange=0.2
Vmean=8
Vnugget=1.2

map=genMap(DataObj=NULL,seed=seed,disp=0,krig=krig,Vpsill=Vpsill,Vrange=Vrange,Vnugget=Vnugget,Vmean=Vmean)

f1=read.table(paste("res-simuseed",seed,"-1q-pE",pErr,".csv",sep=""))
f2=read.table(paste("res-simuseed",seed,"-2q-pE",pErr,".csv",sep=""))
f3=read.table(paste("res-simuseed",seed,"-3q-pE",pErr,".csv",sep=""))
f4=read.table(paste("res-simuseed",seed,"-4q-pE",pErr,".csv",sep=""))
f5=read.table(paste("res-simuseed",seed,"-5q-pE",pErr,".csv",sep=""))
best=unlist(c(f1[1,5],f2[1,5:6],f3[1,5:7],f4[1,5:8]),f5[1,5:9])


# 1q
m1=best[1]
crit1=correctionTree(m1,map,disp=0,SAVE=T)
res=searchNODcrit1(m1,crit1)
jj=res$ind[[1]][1]
zk=crit1$zk
K1=zk[[length(zk)]][[jj]]
val1=valZ(map,K1)$val
ord1=valZ(map,K1)$ord
Z1=K1$zonePolygone
k=0
for (iZ in ord1)
{
k=k+1
Z1=setId(Z1,iZ,k)
}
#

#2q
m2=best[2:3]
crit2=correctionTree(m2,map,disp=0,SAVE=T)
res=searchNODcrit1(m2,crit2)
jj=res$ind[[1]][1]
zk=crit2$zk
K2=zk[[length(zk)]][[jj]]
val2=valZ(map,K2)$val
ord2=valZ(map,K2)$ord
Z2=K2$zonePolygone
k=0
for (iZ in ord2)
{
k=k+1
Z2=setId(Z2,iZ,k)
}
#
m2b=unlist(f2[2,c(5,6)])
names(m2b)=NULL
crit2b=correctionTree(m2b,map,disp=0,SAVE=T)
res=searchNODcrit1(m2b,crit2b)
jj=res$ind[[1]][1]
zk=crit2b$zk
K2b=zk[[length(zk)]][[jj]]
val2b=valZ(map,K2b)$val
ord2b=valZ(map,K2b)$ord
Z2b=K2b$zonePolygone
k=0
for (iZ in ord2b)
{
k=k+1
Z2b=setId(Z2b,iZ,k)
}
#
m2w=unlist(f2[nrow(f2)-1,c(5,6)])
crit2w=correctionTree(m2w,map,disp=0,SAVE=T)
res=searchNODcrit1(m2w,crit2w)
jj=res$ind[[1]][1]
zk=crit2w$zk
K2w=zk[[length(zk)]][[jj]]
val2w=valZ(map,K2w)$val
ord2w=valZ(map,K2w)$ord
Z2w=K2w$zonePolygone
k=0
for (iZ in ord2w)
{
k=k+1
Z2w=setId(Z2w,iZ,k)
}
#3q
m3=best[4:6]
crit3=correctionTree(m3,map,disp=0,SAVE=T)
zk=crit3$zk
res=searchNODcrit1(m3,crit3)
jj=res$ind[[1]][1]
K3=zk[[length(zk)]][[jj]]
val3=valZ(map,K3)$val
ord3=valZ(map,K3)$ord
Z3=K3$zonePolygone
k=0
for (iZ in ord3)
{
k=k+1
Z3=setId(Z3,iZ,k)
}

#4q
m4=best[7:10]
crit4=correctionTree(m4,map,disp=0,SAVE=T)
zk=crit4$zk
res=searchNODcrit1(m4,crit4)
jj=res$ind[[1]][1]
K4=zk[[length(zk)]][[jj]]
val4=valZ(map,K4)$val
ord4=valZ(map,K4)$ord
Z4=K4$zonePolygone
k=0
for (iZ in ord4)
{
k=k+1
Z4=setId(Z4,iZ,k)
}
#
#best zonings for seed  - 2 to 5 labels
name1=paste("bestZ-seed",seed,"-nugget1.2.png",sep="")getwd()
png(name1,width=1600,height=1000)
par(mfrow=c(2,2))

#x11(width=14,height=10)


#png(name1,width=1400,height=1000)
#par(mfrow=c(3,3),mai=c(1,0.54,1,0.28))

ptz=findZCenter(Z1,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z1,cex=2,ptz=ptz)
m=m1
#title(paste("a) Seed=",seed,"-Best zoning for nL=2","\nm=",m,sep=""),cex.main=2)
title(paste("a) Best zoning for nL=2","\nm=",m,sep=""),cex.main=2)
ptz=findZCenter(Z2,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z2,cex=2,ptz=ptz)
m=paste("[",paste(m2,collapse=","),"]",sep="")
title(paste("b) Best zoning for nL=3","\nm=",m,sep=""),cex.main=2)
m=paste("[",paste(m3,collapse=","),"]",sep="")
ptz=findZCenter(Z3,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z3,cex=2,ptz=ptz)
title(paste("c) Best zoning for nL=4","\nm=",m,sep=""),cex.main=2)
m=paste("[",paste(m4,collapse=","),"]",sep="")
ptz=findZCenter(Z4,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z4,cex=2,ptz=ptz)
title(paste("d) Best zoning for nL=5","\nm=",m,sep=""),cex.main=2)
dev.off()

# criterion values for best zonings - seed 53
png(paste("figcritN",seed,"-nugget1.2.png",sep=""))
best=figCritN(seed,m1=f1,m2=f2,m3=f3,m4=f4,m5=f5,NEW=TRUE,ONE=TRUE,pdf=NULL,title="Gau#ssian field simulation")
dev.off()



# single figure with 6 subplots
name2=paste("Zplusdistrib-seed",seed,"-nugget1.2.png",sep="")
png(name2,width=2000,height=1000)
par(mfrow=c(2,3),mai=c(1,0.54,1,0.28))
ptz=findZCenter(Z2,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z2,boundary=map$boundary,nbLvl=0,mu=1,id=TRUE,ptz=ptz,cex=2)
m=paste("[",paste(m2,collapse=","),"]",sep="")
title(paste("Best zoning for nL=3","\nm=",m,sep=""),cex.main=2)
ptz=findZCenter(Z2b,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z2b,boundary=map$boundary,nbLvl=0,mu=1,id=TRUE,ptz=ptz,cex=2)
m=paste("[",paste(m2b,collapse=","),"]",sep="")
title(paste("Second best zoning for nL=3","\nm=",m,sep=""),cex.main=2)
ptz=findZCenter(Z2w,num=NULL)
dispZ(map$step,map$krigGrid,zonePolygone=Z2w,boundary=map$boundary,nbLvl=0,mu=1,id=TRUE,ptz=ptz,cex=2)
m=paste("[",paste(m2w,collapse=","),"]",sep="")
title(paste("Worst zoning for nL=3","\nm=",m,sep=""),cex.main=2)

# colors
palCoul=colorRampPalette(c("brown","yellow"))

boxplot(val2,cex.axis=3,col=palCoul(length(val2)))
title("Distribution of values within zones",cex.main=3)
boxplot(val2b,cex.axis=3,col=palCoul(length(val2b)))
title("Distribution of values within zones",cex.main=3)
boxplot(val2w,cex.axis=3,col=palCoul(length(val2w)))
title("Distribution of values within zones",cex.main=3)

dev.off()

system(paste("convert ",name1," ",name1,".pdf",sep=""))

}

#concatenate all pdfs
#system("pdftk bestZ*.pdf cat output allZsimus-nugget1.2.pdf")
}

